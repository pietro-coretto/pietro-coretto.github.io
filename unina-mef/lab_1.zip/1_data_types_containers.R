# Basic math operations
5 + 2

5 * 2

5 - 2

5/2

2^2

2^{1/3}

2 / 0

Inf/3

0 * Inf

Inf - Inf




## Basic math functions
## ********************

sqrt(4)

exp(2)

log(exp(4))

sin(pi)

cos(pi)

round(2.6589555668855, digits = 3)






## Memory and local variables
## **************************

a <- 5

a -> 5

## !! See error
5 <- a

5 -> a

b <- 2

a + b

a * b

a / b

u <- a+b
u

a <- 10


u <- a+b
u

## WARNING: do not use "T, F, c" for naming local variables
a1 <- 6

## List objects in the 'local' memory/workspace
ls()










## Types
## *****

## floating point
2/3

## Integer
1L

## Character
x <- "XYZ322255h"
x

## Logic
x <- TRUE
x

y <- FALSE
y



##  Special types NA, NaN and  NULL
x <- NULL
x * 2

x <- NA
x * 2

x <- NaN
x * 2





##  Logic operators
##  ****************

A <- FALSE

B <- TRUE

## negation 
! A

## equal
A == B

## not equal to 
A != B

## AND
A & B

## OR
A | B


## convert logical to numerical type
as.numeric(A)
as.numeric(B)


## conversion is performed automatically if we apply arithmetic operators
A * B

A + B










## CONTAINERS
## **********************************************************************
##   * organize/reference data in the memory
##   * each container has restrictions on the type that it can contain
##   * each container has a way to access its members (indexing, slicing)
##
## Typical R containers:
##   * array (includes vectors and matrices as special cases)
##   * data.frame
##   * list








## Vector
## *************************************************
##   * the simplest array
##   * only one type
##   * one index (one dimension) to pick an element

x <- c(10,4,-1,100,3,7,93)
x

## element-wise operation, this is not linear algebra
x <- c(2,  3)
x

x + x

x / x

x^2

## "computer vectors" are different from "math vectors"... see this
y <- c(1,1,2,2)
y

x+y

x*y


## Subsetting / indexing / slicing vectors

## Method 1
## Pick elements based on indexes
x <-  c(10,4,-1,100,3,7,93, 3)

x[1]

x[1:3]

x[-1:-3]

## we want pick the 1st and the 4th
x[c(1,4)]


## Method 2
x == 3



## Pick elements based on logical operators
x[x == 3]



## same thing if do
u <- x == 3
u

x[u]


## other logical operators 
## get all x larger than 11
x[x > 11]

## get all x smaller than 1
x[x <1 ]

## get all x larger than 0 and smaller or equal to 7
x[x>0 & x<=7]


## It works the same on char types
y <- c("This","are","strings")
y

y[ y == "This"]

y[ y == "this"]



## WARNING: a vector contains the same type  !!
x <- c("Foo", 2)
x















## Factors
## *****************************************************************
##    * vectors with additional attributes
##    * particularly tailored to statistics (qualitative variables)
##    * they have attributes that manage levels and ordering

risk <- factor(c("high", "median", "low"))
risk

## Orderedering
risk    <- factor(c("H", "H", "L", "M", "H", "M", "L"), 
                  levels=c("L", "M", "H"), ordered=TRUE)
risk

as.numeric(risk)








## Arrays
## *******************************************************************
##    * only one type
##    * an array of dimension k needs k indexes to pick one data point
##    * 1-dimensional arrays are called vectors
##    * 2-dimensional arrays are called tables
##

## 2D-array (aka tables)
A <- array(1:9, dim=c(3,3))
A

dim(A)

## subsetting 
A[1,1]

A[1, ]

A[-1 , ]

A[ , -1]

A[1:2, ]

A[, c(1,3)]







## 3D-array (a sort of set of tables)
B <- array(1:32, dim=c(3,3,4))
B


B[1,1,1]

B[3,3,3]

## select rows 1-2 and cols 1-2 on 3rd table
B[1:2, 1:2, 2]


dim(B)




## Matrices (2D arrays)
## *****************************************************************************
##    * a special type of  2-dimensional arrays on which we can do matrix algebra
##      operations (det, inverse, matrix-product, transpose, etc.)
##    * need two indexes to pick up a data point
##    * can be passed trough matrix algebra operations

x   <- matrix(c(1,2,3,4), nrow=2, ncol=2)
x

y   <- matrix(c(1,2,3,4), nrow=2)
y

x1   <-c(1,2,3)
x2   <-c(10,20,30)
x3   <-c(100,200,300)

data    <-c(x1,x2,x3)

X    <- matrix(data, nrow=3, byrow = TRUE)
X

Y    <-matrix(data, nrow=3, byrow=FALSE)
Y

Z    <- cbind(x1,x2,x3)
Z

Z    <- rbind(x1,x2,x3)
Z


## subsetting: same as 2D-arrays


## Matrix algebra
X  <- matrix(1:25 , ncol=5)


# Element-wise operations !!! These are not always matrix algebra operations
X * X
X / X
X - 2*X
X^2


## Matrix operations
X %*% X    ## row-column matrix multiplication

t(X)

det(X)

w <- jitter(X)

solve(w)

diag(X)

dim(X)

## Identity matrix
U <- diag(1, 4)

## Extract diagonal
diag(U)

## Replace the the diagonal
W <- matrix(0, ncol=3, nrow=3)
W
diag(W) <- c(10,11,20)
W





## LISTS
## *******************************************************************
##    * most flexible data containers
##    * each element of the list can be itself a container
##    * very useful to pack results of a complex statistical analysis
##      (e.g. output of OLS)

H <- list(student="Tyler Durden", score=c(18,30,18), gender="M")

H

names(H)

H$student

H[[1]]

H$score

H[[2]]











## Data-frames
## ***********************************************************
##    * one of the things that made R so popular
##    * it's basically a list with some restriction
##    * but it looks like a table (2D-array)
##    * each column *must be* of the same type (restriction)
##    * ideal to store a  dataset for statistical analysis


n <- c("Ron Woodroof", "Christiane Vera Felscherinow" , "Jeffrey Lebowski")
g <- factor(c("M", "F", "M"))
a <- c(38,20,42)

mydata <- data.frame(Name=n, Gender=g, Age=a)

mydata

names(mydata)



## subsetting

mydata$Name

mydata[[1]]

mydata[1]

## each col can be sliced using the usual technique for vectors
mydata$Name[1]

mydata$Name[1:2]

mydata$Name[-2]















## ================================ SELF-STUDY  ================================
## Go over the previous commands once again and then experiment with the
## followings
## =============================================================================

## help and documentation 
?var

help(var)


apropos("var")

help.search("regression")




## Several useful functions and tricks  
x <- c(10,20,33,33,33,-10,1)

sum(x)

sum(x^2)

cumsum(x)

length(x)

which(x >= 1)

idx <- x>=20
    
which(idx)

which.max(x)

which.min(x)

rev(x)

sort(x, decreasing = FALSE)

sort(x, decreasing = TRUE)

unique(x)


## Manage NAs
y <- c(10, NA, 100, 0, 0, NA)
is.na(y)
y[is.na(y)]
which(is.na(y))
y[is.na(y)]
y[!is.na(y)]
sum(is.na(y))
sum(!is.na(y))



## generating sequences
s1 <- 1:10
s1

s2 <- seq(from=1,to=10, length=10)
s2

s3 <- seq(1,pi, length=10)
s3

s4 <- seq(1,pi, by = 0.05)
s4

s5 <- rep(5,10)
s5

s6 <- 1:pi

