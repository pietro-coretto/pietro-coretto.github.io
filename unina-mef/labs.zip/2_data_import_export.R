## Useful functions to manage the working directory
getwd()
dir()

## Set the current working dir
## setwd("path")


## You can do this using the RStudio main menu:
##    Session --> Set Working Directory --> Choose Directory

## Now make sure that your working directory is set to the path where you
## copied: DataSetA.csv   DataSetB.dat
dir()

## If it's not the case, copy the files in the current working directory, or
## set the working directory where you copied those files






## Commmon data import situations:
## ************************************************************************
##
## * dataset format is a table (rows x columns)
## * data storage techniques:
##    -comma-separated-values stored in ACII files
##    -tab-separated-values   stored in ASCII files
##    -some container that is stored in a format that is software specific





## Reading comma-separated-values stored in ACII files
## *****************************************************************************
##    * typically a ASCII files with a .csv  extension
##    * rows are sparated by the RET control character (carriage return key)
##    * columns are separated by a comma character (,)
##    * WARNING: numbers separated by a comma can a problem 
##      (e.g. ten thousand = 10,000)
##    * WARNING: does the first row contain data?


## The function read.csv()  is a wrapper for read.table(), where sep=',' by default
X  <- read.csv(file="DataSet_X.csv", header=TRUE)
X

## WARNING: what about the imported data-types?
str(X)





## Reading tab-separated-values stored in ACII files
## *****************************************************************************
##    * typically a ASCII files with a .dat or .txt extension
##    * rows are sparated by the RET control character (carriage return key)
##    * columns are separated by a tab escape sequence (TAB key, or \t sequence)
##    * WARNING: does the first row contain data?
Y  <- read.table(file="DataSet_Y.dat",  header=TRUE)
Y


## WARNING: what about the imported data-types?
str(Y)





## Reading software specific file formats
## *****************************************************************************
##    * R can store data in its RData file format
##    * RData files can store any type of R objects with its own object's attributes
##    * the file DataSet_Z.RData contain a data.frame named Z
load(file="DataSet_Z.RData")
Z

## and now
str(Z)

## Other scommon software-specific storage formats
##
##    * xls:   MS Excell storage format
##    * dta:   STATA storage format
##    * spss:  SPSS storage format
##    * mat:   MATLAB storage format
##    * etc
##
##   If you need to read this file, look for specialized R packages such as
##   foreign, gdata, xls, etc









## Formatting an unformatted dataset:
## ***********************************************************************
##    * ASCII files do not store attributes about types, containers, etc
##    * as default R reads a 2-Array as a data.frame
##    * as default R reads numbers as floating points (numeric)
##    * as default R reads strings as unordered factors

# Let's go back to the imported CSV file
str(X)

# One possible solution is to tell R what it must read by setting the options
# in read.table function. Another possibility is fix the default import, let's
# do this

## The 2nd and 5th column are ok


## The 3rd column has to be trated as an unordered factor, so this is ok!

## But the 4th column has to be trated as an ordered factor
X$Risk <- factor(X$Risk, levels = c("Low","Medium", "High"), ordered = TRUE)


## The 1st column is a date formatted as d/m/y, not that this as been read as chr
## Calendar dates are complex numerical objects
X$Date <- as.Date(X$Date,   format="%d/%m/%y")


## Typically we wanto to work on the dataset in future sessions, and we don't
## want to loose the formatting we have performed. The best thing to do is to
## save X in a RData files for future use
save(X, file="foo_X.RData")














## ================================ SELF-STUDY  ================================
## Go over the previous commands once again and then experiment with the
## followings
## =============================================================================

## Calendar dates
X$Date[3] - X$Date[1]

format(X$Date, "%B")

format(X$Date, "%d %a %B %Y")



## File may also be a remote url address, you just need to parse the address via
## the url() function.

## apple data: https://pietro-coretto.github.io/datasets/apple/readme.txt
AppleData <- read.table(file=url("https://pietro-coretto.github.io/datasets/apple/apple.dat"), header=TRUE)
str(AppleData)

## data: https://pietro-coretto.github.io/datasets/nls80/readme.txt
##
load(file=url("https://pietro-coretto.github.io/datasets/nls80/nls80.RData"))
str(NLS80)


## Other useful function to inspect data sets
dim(NLS80)

head(NLS80)

tail(NLS80)

## The following is RStudio specific
View(NLS80)


## Save more than one R object into a RData file
U <- list(A=1, B=2, C=NA)
save(list=c("U", "X"), file="foo.RData")

## Close the current R session and open a new R session read, then Read the file
## and inspect the workspace
load("foo.RData")
ls()







