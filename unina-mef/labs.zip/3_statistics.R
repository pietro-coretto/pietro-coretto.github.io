## Probability distributions: syntax
##
## rDISTNAME = random generation
## dDISTNAME = density function
## pDISTNAME = (cumulative) distribution function
## qDISTNAME = quantile function


## Distribution     DISTNAME
## ==========================
## Normal           norm
## Uniform          unif
## Student-t        t
## Chi^2            chisq
## F                f
## Log-Normal       lognormal
## Binomial         binom
## Poisson          pois
## Exponential      exp


## Examples
set.seed(2018)

u <- rnorm(n=10, mean = 0, sd=1)
u

## density
dnorm(x=3, mean = 0, sd=1)
dnorm(x=c(-3,3), mean = 0, sd=1)


## cdf
pnorm(q=3, mean = 0, sd=1)
pnorm(q=c(-3,3), mean = 0, sd=1)


## quantile function 
qnorm(p=0.5, mean = 0, sd=1)
qnorm(p=c(0.25, 0.5, 0.75), mean = 0, sd=1)






## (re)sammpling
x <- c(1,20,3,4)

## uniform propbability sampling with replacement 
sample(x, size=10, replace=TRUE)

## uniform propbability sampling without  replacement 
sample(x, size=3, replace=FALSE)

## non uniform sampling 
sample(x, size=10, replace=TRUE, 
       prob=c(0.1, 0.7, 0.05, 0.15))





## Sample Statistics
set.seed(1)
x <- rt(100, df=3)

## location statistics
mean(x) ## sample mean

median(x) ## sample median with averaging at discontinuities

quantile(x, probs=c(0.25,0.5,0.75))



## scale statistics
var(x) ## unbiased sample variance

sd(x)  ## unbiased sample standard deviation

IQR(x) ## IQR qith type 7 quantiles








## non-parametric estimates
set.seed(1)
x <- rnorm(n=20)

## ECD function (Empirical Cumulative Distribution Function)
plot(ecdf(x))


## Sample more data
set.seed(1)
x <- rnorm(n=1000)


## histogram
## check ?hist for more options 
h1 <- hist(x, plot=FALSE)
h1
plot(h1)


## kernel density with the default gaussian bandwidth
d <- density(x)
d
plot(d)




## Frequency and counts
## --------------------

set.seed(1)
ni <- rpois(n = 52, lambda = 2)
ni

## tabulate the counts (frequencies)
table(ni)

## percentage scale
table(ni)/length(ni) * 100


## works with factors
set.seed(10)
u <- sample(c("A","B", "C"), size = 60, replace = TRUE)
u <- factor(u) 
table(u)


## we window x into classes of values
set.seed(100)
x <- runif(1000)
range(x)

## transform a continuous variable into slices
cx <- cut(x, breaks = 4)
cx
table(cx)








    
    
## Multivariate statistics
set.seed(1)
x <- rnorm(n=100)
y <- 2*x + rt(n=100, df=3)

## unbiased sample covariance
cov(x,y)

## unbiased sample covariance
cor(x,y)

## location-scatter statistics
##
A <- cbind(x=x, y=y)


## compute sample mean vector of the col-vectors
colMeans(A)


## you can do the same thing using an apply-type function
apply(A, MARGIN = 2, FUN = mean)

## compute the median of col-vectors
apply(A, MARGIN = 2, FUN = median)

## unbiased sample variance-covariance matrix
cov(A)

## unbiased sample correlation matrix
cor(A)





## Missing values
set.seed(1)
x <- rnorm(n=12)
y <- 2*x + rt(n=12, df=3)
x[1:4] <- NA
y[1:2] <- NA
U <- cbind(x=x, y=y)
U

## Compare
mean(x)
colMeans(U)
apply(U, 2, median)


## A crude technique for handling missing  values is to ignore them... however,
## this reduces the effective sample size, soetimes it produces severe
## sample-selection bias effects
mean(x, na.rm = TRUE)








## ================================ SELF-STUDY  ================================
## Go over the previous commands once again and then experiment with the
## followings
## =============================================================================

## Generate a big 100x10 matrix
set.seed(100)
X <- matrix(rnorm(100 * 10), ncol = 10)

## compute the standard deviation of col-vectors
apply(X, MARGIN = 2, FUN = sd)

## compute the IQR on col-vectors
apply(X, MARGIN = 2, FUN = IQR)


## compute row-vectors sums
apply(X, 1, sum)

## understand why this is  equivalent to  computing l1-norm for each row-vector
apply(abs(X), 1, sum)


## understand why this is  equivalent to  computing l2-norm for each col-vector
sqrt( apply(X^2, 2, sum) )


## Special actions for missing values
cov(U)

## Explore the the help function and understand what the following commands do
cov(x,y, use="all.obs")
cov(x,y, use="complete.obs")
cov(x,y, use="pairwise.complete.obs")




#

