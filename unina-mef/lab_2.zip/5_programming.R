## Iterating

## FOR loop
## ------------------------------------------------------
## for(indeces){ 
##     operation at current index value 
## }

## example: we want to compute the terms of the equation
## x_{t+1} = 1 + 2*x_{t}
## with t=1,2,...10, and x_{1} = 0

## Initialization: we always need to initialize a container
## for storing values with appropriate size
x <- rep(0, 10) # Intialization

## for loop 
for (t in 1:9) {
   x[t+1] <- 1 + 2 * x[t]
}
x








## While Statement
## ---------------------------------------------------------

## while(condition){
##    operation
## }

## example 
iter <- 1
x    <- 1
while (x < 1000 & iter <= 1000) {
   message('Performing iteration:...', iter)
   x    <- 2*x
   iter <- iter+1
}

## Check calculations
x
iter







## IF statements
## ---------------------------------------------------------

## if (condition){
##    operation
##   }

x  <- c(1,2)
if (length(x) >= 3){
   out <- x^2
}
out

x  <- c(1,2)
if (length(x)<3) {
   out <- x^2
}
out







## IF-ELSE statements
## ***********************************************
# if(condition){
#    operation
# }else{
#    operation
# }
#
# if(condition){
#    operation
# }else if(condition){
#    operation
# }

x<-c(1,2)
if (length(x)>=3) {
   A <- x^2
}else if(length(x)==1){
   B <- 3*x
}else{
   message("I don't know what to do...")
}









## Building Functions
## -------------------------------------------------------------
## function_name <- function(args) {
##    compute an output
##    return(output)  
## }


## volume of a cylinder
cylvol <- function(height, radius){
   y <- pi * radius^2 * height
   return(y)
   }

cylvol(height = 10, radius = 1)



## fix default arguments 
cylvol <- function(height, radius = 1){
   y <- pi * radius^2 * height
   return(y)
}
cylvol(height = 10)



## function we more outputs
cylvolsurf <- function(height, radius = 1){
   a <- pi * radius^2 * height
   b <- 2*pi*radius*{height + radius}
   
   ans <- list(Volume = a, TotalSurface = b)
   
   return(ans)
}
cylvolsurf(height = 10, radius = 10)






## combine a function with apply type R functions
set.seed(2569857)
A <- data.frame(X1 = rnorm(100), X2=rt(100, df = 3))

## suppose I want to compute 
##     Y = 2*X1 + 3*log(abs(X2)) 
## for each unit (rows of A)
yfunc <- function(x){
   y <-  2*x[1] + 3*log(abs(x[2])) 
   return(y)
}

## we compute the y-function on the first row of A
yfunc(A[1, ])


## do this for each row of A
apply(A, MARGIN=1, FUN = yfunc)





## Useful functions to print outputs
## ---------------------------------

## Concatenate strings
a <- paste("AAA", "BBB", "CCCC", sep = "***")
a

b <- paste("AAA", "BBB")
b 


u = 100
d <- paste("Value of u is", u, sep = " ")
d



## print objects
print(cylvolsurf)

A <- matrix(1:10, ncol = 2)
print(A)




## Concatenate and print in a single instance
cat(a)

cat("AAA", "BBB", sep = "***")

cat(A)



## write message to a console 
message("The matrix A is ")
print(A)




## Scripts/program
## ******************************************************************

## A script can include functions and sequential operations.

## First have a look at "MyFirstProgram.R",

## Clean the workspace
rm(list=ls())

## Check what's in the workspace (memory)
ls()

## Execute the program contained in the script. Note that if the script file
## is not in your current working directory you have to either set the working
## directory, or give full file path
source("MyFirstProgram.R")

## let's see the memory now 
ls()








































#
