## Basic XY-plot functions
## ********************
set.seed(1)
x <- rnorm(10)

plot(x)

plot(x, main="Title", xlab="x axis", 
     ylab="y lab", col=2, pch="+")

## Close graphic device
dev.off()

## Open multiple graphic devices
x11()
plot(x)
x11()
plot(x, main="Title", xlab="x axis", ylab="y lab", col=2, pch="+")





## PLot types
plot(x, t='p')

plot(x, t='l')

plot(x, t='b')

plot(x, t='h')




## Adding vertical and horizontal line
plot(x, t='h')
abline(h=0, col=2)
abline(v=4.5, col=4)








## Example of a serious plot (see what you can do)
## -----------------------------------------------

##... generate data 
x  <- seq(-4*pi, 4*pi, length=1000)
fx <- sin(x)
gx <- cos(x)

## Define personalized color using the HTML code
## see: https://htmlcolorcodes.com/
col1 <- "#376DEE"
col2 <- "#199C5A"
col3 <- "#34495E"

## plot fx
plot(x, fx, t="l", col=col1, lwd=4
     , main="Trigonometric functions", 
     xlab="radiants", ylab="f(x)")
## add gx
lines(x, gx, col=col2, lwd=4, lty=3)
## add grid
grid(col = col3, lty = 2)
## add verticol line at 0
abline(v = 0, col = "red")
## add horinzontal line at 1 and -1
abline(h = c(-1,1), col = "red")
## add legend at the top-right corner 
legend(x="topright", legend=c("sin(x)", "cos(x)")
      , lwd=c(2,2), lty=c(1,3), col=c(col1, col2))








## Multiple plots in a single graphic window
## -----------------------------------------

## generate some data 
set.seed(2019)
x <- rchisq(100, df=3)

## key parameters: split a single window onto 2 rows x 2 colums 
par(mfrow=c(2,2))

## fill in plots 
plot(x, main='Plot A')
hist(x, main='Plot B')
plot(density(x), main='Plot C')
boxplot(x, main='Plot D')






## Multivariate pairweise scatter plots 
X <- read.table(file=url("http://www.decg.it/pcoretto/datasets/apple_data.dat"), 
                header=TRUE)

# plot the scatter ov vCap vs vMat
plot(X$vCap , X$vLab, xlab = "Value of Capital", 
     ylab = "Value of Labour", pch = 20, cex = 2,
     col = 10) 

## all pairwise scatter plots 
pairs(X[, 1:6])








## ================================ SELF-STUDY  ================================
## Go over the previous commands once again and then experiment with the
## followings
## =============================================================================

## use the help and study and experiment the following functions

?stripchart

?qqnorm












