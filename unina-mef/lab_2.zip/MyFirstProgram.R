## =============================================================================
## Author: Pietro Coretto (pcoretto@unisa.it)
##
## Last update: 2019/01/09 15:10:02
##
## Program Description
## *******************
## This program import the dataset
##            http://www.decg.it/pcoretto/datasets/apple_data.dat
## then returns the average and standard deviation of vCap on the console.
## Finally it shows the histogram of the vcap distribution and it save it to a
## local pdf file
## =============================================================================


## Read the dataset
message("Reading data:.... please wait")
X <- read.table(file=url("http://www.decg.it/pcoretto/datasets/apple_data.dat"), 
                header=TRUE)


## Compute the sample mean of vCap
avg_vCap  <- mean(X$vCap)


## Output on the screen
message("The sample mean of  vCap is = ", avg_vCap , '\n')


## Compute the histogram
h <- hist(X$vCap, breaks='FD')

## Show  and save the histogram
pdf(file="hist_vCap.pdf", width = 8, height = 7)
plot(h)

## Close the graphic device
dev.off()
